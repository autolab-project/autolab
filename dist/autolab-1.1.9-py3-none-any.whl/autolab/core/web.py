# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 17:11:57 2019

@author: qchat
"""

import webbrowser

def report():
    webbrowser.open('https://github.com/qcha41/autolab/issues')
    
def doc():
    webbrowser.open('https://autolab.readthedocs.io')
